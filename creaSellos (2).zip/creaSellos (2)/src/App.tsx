import { useRef, useEffect } from 'react';
import { fabric } from 'fabric';
import { Header } from './components/Header';
import { Toolbar } from './components/Toolbar';
import { StampCanvas } from './components/StampCanvas';
import { ShapePanel } from './components/ShapePanel';
import { PropertiesPanel } from './components/PropertiesPanel';
import './App.css';

export default function App() {
  const canvasRef = useRef<fabric.Canvas | null>(null);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const fc = canvasRef.current;
      if (!fc) return;
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.key === 'Delete' || e.key === 'Backspace') {
        const active = fc.getActiveObjects();
        active.forEach((obj) => fc.remove(obj));
        fc.discardActiveObject();
        fc.renderAll();
      }
      if (e.key === 'Escape') {
        fc.discardActiveObject();
        fc.renderAll();
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  return (
    <div className="app">
      <Header canvasRef={canvasRef} />
      <div className="workspace">
        <div className="left-panel">
          <Toolbar canvasRef={canvasRef} />
          <ShapePanel canvasRef={canvasRef} />
        </div>
        <div className="canvas-area">
          <div className="canvas-viewport">
            <StampCanvas canvasRef={canvasRef} />
          </div>
        </div>
        <PropertiesPanel canvasRef={canvasRef} />
      </div>
    </div>
  );
}
