import { type ShapeAsset } from '../types';

export const SHAPES: ShapeAsset[] = [
  // Basic
  { id: 'circle', name: 'Círculo', category: 'basic', path: '/shapes/basic/circle.svg', preview: '/shapes/basic/circle.svg' },
  { id: 'rectangle', name: 'Rectángulo', category: 'basic', path: '/shapes/basic/rectangle.svg', preview: '/shapes/basic/rectangle.svg' },
  { id: 'triangle', name: 'Triángulo', category: 'basic', path: '/shapes/basic/triangle.svg', preview: '/shapes/basic/triangle.svg' },
  { id: 'star5', name: 'Estrella 5p', category: 'basic', path: '/shapes/basic/star5.svg', preview: '/shapes/basic/star5.svg' },
  { id: 'star6', name: 'Estrella 6p', category: 'basic', path: '/shapes/basic/star6.svg', preview: '/shapes/basic/star6.svg' },
  { id: 'hexagon', name: 'Hexágono', category: 'basic', path: '/shapes/basic/hexagon.svg', preview: '/shapes/basic/hexagon.svg' },
  { id: 'diamond', name: 'Diamante', category: 'basic', path: '/shapes/basic/diamond.svg', preview: '/shapes/basic/diamond.svg' },
  { id: 'oval', name: 'Óvalo', category: 'basic', path: '/shapes/basic/oval.svg', preview: '/shapes/basic/oval.svg' },
  // Decorative
  { id: 'double-circle', name: 'Doble círculo', category: 'decorative', path: '/shapes/decorative/double-circle.svg', preview: '/shapes/decorative/double-circle.svg' },
  { id: 'double-rect', name: 'Doble marco', category: 'decorative', path: '/shapes/decorative/double-rect.svg', preview: '/shapes/decorative/double-rect.svg' },
  { id: 'dashed-circle', name: 'Círculo punteado', category: 'decorative', path: '/shapes/decorative/dashed-circle.svg', preview: '/shapes/decorative/dashed-circle.svg' },
  { id: 'rounded-rect', name: 'Marco redondeado', category: 'decorative', path: '/shapes/decorative/rounded-rect.svg', preview: '/shapes/decorative/rounded-rect.svg' },
  { id: 'banner', name: 'Banner', category: 'decorative', path: '/shapes/decorative/banner.svg', preview: '/shapes/decorative/banner.svg' },
  { id: 'shield', name: 'Escudo', category: 'decorative', path: '/shapes/decorative/shield.svg', preview: '/shapes/decorative/shield.svg' },
  { id: 'wave-circle', name: 'Círculo ondulado', category: 'decorative', path: '/shapes/decorative/wave-circle.svg', preview: '/shapes/decorative/wave-circle.svg' },
  // Symbols
  { id: 'star-solid', name: 'Estrella sólida', category: 'symbols', path: '/shapes/symbols/star-solid.svg', preview: '/shapes/symbols/star-solid.svg' },
  { id: 'crown', name: 'Corona', category: 'symbols', path: '/shapes/symbols/crown.svg', preview: '/shapes/symbols/crown.svg' },
  { id: 'heart', name: 'Corazón', category: 'symbols', path: '/shapes/symbols/heart.svg', preview: '/shapes/symbols/heart.svg' },
  { id: 'arrow-right', name: 'Flecha', category: 'symbols', path: '/shapes/symbols/arrow-right.svg', preview: '/shapes/symbols/arrow-right.svg' },
  { id: 'checkmark', name: 'Tilde', category: 'symbols', path: '/shapes/symbols/checkmark.svg', preview: '/shapes/symbols/checkmark.svg' },
  { id: 'leaf', name: 'Hoja', category: 'symbols', path: '/shapes/symbols/leaf.svg', preview: '/shapes/symbols/leaf.svg' },
  { id: 'cross', name: 'Cruz', category: 'symbols', path: '/shapes/symbols/cross.svg', preview: '/shapes/symbols/cross.svg' },
  { id: 'infinity', name: 'Infinito', category: 'symbols', path: '/shapes/symbols/infinity.svg', preview: '/shapes/symbols/infinity.svg' },
];
