import { fabric } from 'fabric';
import { type StampSize, type StampShape, DISPLAY_PX_PER_MM } from '../types';

export function exportToPng(
  canvas: fabric.Canvas,
  stampSize: StampSize,
  stampShape: StampShape,
  dpi: number = 300
): void {
  const exportPxPerMm = dpi / 25.4;
  const multiplier = exportPxPerMm / DISPLAY_PX_PER_MM;

  const exportWidth = Math.round(stampSize.widthMm * exportPxPerMm);
  const exportHeight = Math.round(stampSize.heightMm * exportPxPerMm);

  // For circular stamps, clip to circle during export
  if (stampShape === 'circle') {
    const ctx = (canvas as any).getContext('2d') as CanvasRenderingContext2D;
    ctx.save();
  }

  const dataUrl = canvas.toDataURL({
    format: 'png',
    multiplier,
    quality: 1,
  });

  const link = document.createElement('a');
  link.download = `sello_${stampSize.widthMm}x${stampSize.heightMm}mm_${dpi}dpi.png`;
  link.href = dataUrl;
  link.click();

  console.log(`Exportado: ${exportWidth}×${exportHeight}px @ ${dpi} DPI (${stampSize.widthMm}×${stampSize.heightMm}mm)`);
}

export function getExportDimensions(stampSize: StampSize, dpi: number = 300) {
  const exportPxPerMm = dpi / 25.4;
  return {
    widthPx: Math.round(stampSize.widthMm * exportPxPerMm),
    heightPx: Math.round(stampSize.heightMm * exportPxPerMm),
    dpi,
    widthMm: stampSize.widthMm,
    heightMm: stampSize.heightMm,
  };
}
