import { create } from 'zustand';
import { type StampSize, STAMP_SIZES, type StampShape } from '../types';

interface SelectedObjectProps {
  fontSize?: number;
  fontFamily?: string;
  fill?: string;
  fontWeight?: string;
  fontStyle?: string;
  textAlign?: string;
  opacity?: number;
  strokeWidth?: number;
  stroke?: string;
  scaleX?: number;
  scaleY?: number;
}

interface StampStore {
  stampSize: StampSize;
  setStampSize: (size: StampSize) => void;

  activeTool: 'select' | 'text' | 'shape';
  setActiveTool: (tool: 'select' | 'text' | 'shape') => void;

  selectedObjectProps: SelectedObjectProps | null;
  setSelectedObjectProps: (props: SelectedObjectProps | null) => void;

  stampBackground: string;
  setStampBackground: (color: string) => void;

  stampBorderColor: string;
  setStampBorderColor: (color: string) => void;

  stampShape: StampShape;
  setStampShape: (shape: StampShape) => void;
}

export const useStampStore = create<StampStore>((set) => ({
  stampSize: STAMP_SIZES[0],
  setStampSize: (size) => set({ stampSize: size }),

  activeTool: 'select',
  setActiveTool: (tool) => set({ activeTool: tool }),

  selectedObjectProps: null,
  setSelectedObjectProps: (props) => set({ selectedObjectProps: props }),

  stampBackground: '#ffffff',
  setStampBackground: (color) => set({ stampBackground: color }),

  stampBorderColor: '#000000',
  setStampBorderColor: (color) => set({ stampBorderColor: color }),

  stampShape: 'rectangle',
  setStampShape: (shape) => set({ stampShape: shape }),
}));
