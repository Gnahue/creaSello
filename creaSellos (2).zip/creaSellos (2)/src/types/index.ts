export type StampShape = 'rectangle' | 'circle';

export interface StampSize {
  label: string;
  widthMm: number;
  heightMm: number;
  shape: StampShape;
}

export interface ShapeAsset {
  id: string;
  name: string;
  category: 'basic' | 'decorative' | 'symbols';
  path: string;
  preview: string;
}

export const STAMP_SIZES: StampSize[] = [
  { label: '40×25mm', widthMm: 40, heightMm: 25, shape: 'rectangle' },
  { label: '50×30mm', widthMm: 50, heightMm: 30, shape: 'rectangle' },
  { label: '60×40mm', widthMm: 60, heightMm: 40, shape: 'rectangle' },
  { label: '30×30mm', widthMm: 30, heightMm: 30, shape: 'rectangle' },
  { label: '40×40mm', widthMm: 40, heightMm: 40, shape: 'rectangle' },
  { label: 'Redondo 30mm', widthMm: 30, heightMm: 30, shape: 'circle' },
  { label: 'Redondo 40mm', widthMm: 40, heightMm: 40, shape: 'circle' },
  { label: 'Redondo 50mm', widthMm: 50, heightMm: 50, shape: 'circle' },
];

export const DISPLAY_PX_PER_MM = 6;
export const EXPORT_DPI = 300;
export const EXPORT_PX_PER_MM = EXPORT_DPI / 25.4;

export const FONTS = [
  'Arial',
  'Georgia',
  'Times New Roman',
  'Courier New',
  'Verdana',
  'Impact',
  'Trebuchet MS',
  'Palatino',
];
