import { fabric } from 'fabric';
import { useStampStore } from '../store/useStampStore';
import { FONTS } from '../types';

interface PropertiesPanelProps {
  canvasRef: React.MutableRefObject<fabric.Canvas | null>;
}

function ColorInput({ value, onChange, label }: { value: string; onChange: (v: string) => void; label: string }) {
  return (
    <div className="prop-row">
      <label className="prop-label">{label}</label>
      <div className="color-input-wrap">
        <input type="color" value={value || '#000000'} onChange={(e) => onChange(e.target.value)} className="color-picker" />
        <span className="color-hex">{value || '#000000'}</span>
      </div>
    </div>
  );
}

export function PropertiesPanel({ canvasRef }: PropertiesPanelProps) {
  const { selectedObjectProps, setSelectedObjectProps, stampBackground, setStampBackground } = useStampStore();

  const getActiveObject = () => canvasRef.current?.getActiveObject() ?? null;

  const applyAndSync = (obj: fabric.Object, props: Record<string, unknown>) => {
    const fc = canvasRef.current;
    if (!fc) return;
    obj.set(props as fabric.IObjectOptions);
    fc.renderAll();
    setSelectedObjectProps({ ...selectedObjectProps, ...props });
  };

  const updateProp = (props: Partial<fabric.IText & fabric.Object>) => {
    const obj = getActiveObject();
    if (!obj) return;
    applyAndSync(obj, props as Record<string, unknown>);
  };

  const updateFill = (color: string) => {
    const fc = canvasRef.current;
    const obj = getActiveObject();
    if (!fc || !obj) return;
    obj.set({ fill: color });
    if (obj.type === 'group') {
      (obj as fabric.Group)._objects?.forEach((child) => {
        if (child.fill !== 'transparent') child.set({ fill: color });
      });
    }
    fc.renderAll();
    setSelectedObjectProps({ ...selectedObjectProps, fill: color });
  };

  const updateStroke = (color: string) => {
    const fc = canvasRef.current;
    const obj = getActiveObject();
    if (!fc || !obj) return;
    obj.set({ stroke: color });
    if (obj.type === 'group') {
      (obj as fabric.Group)._objects?.forEach((child) => {
        child.set({ stroke: color });
      });
    }
    fc.renderAll();
    setSelectedObjectProps({ ...selectedObjectProps, stroke: color });
  };

  const updateOpacity = (val: number) => {
    const obj = getActiveObject();
    if (!obj) return;
    applyAndSync(obj, { opacity: val / 100 });
  };

  const isText = selectedObjectProps && ('fontSize' in selectedObjectProps);

  return (
    <div className="properties-panel">
      <div className="panel-header">Propiedades</div>

      <div className="prop-section">
        <div className="prop-section-title">Fondo del sello</div>
        <ColorInput label="Color fondo" value={stampBackground} onChange={setStampBackground} />
      </div>

      {selectedObjectProps ? (
        <>
          {isText && (
            <div className="prop-section">
              <div className="prop-section-title">Texto</div>
              <div className="prop-row">
                <label className="prop-label">Fuente</label>
                <select
                  className="prop-select"
                  value={selectedObjectProps.fontFamily ?? 'Arial'}
                  onChange={(e) => updateProp({ fontFamily: e.target.value })}
                >
                  {FONTS.map((f) => (
                    <option key={f} value={f} style={{ fontFamily: f }}>{f}</option>
                  ))}
                </select>
              </div>
              <div className="prop-row">
                <label className="prop-label">Tamaño</label>
                <input
                  type="number"
                  className="prop-input"
                  min={4}
                  max={200}
                  value={selectedObjectProps.fontSize ?? 24}
                  onChange={(e) => updateProp({ fontSize: Number(e.target.value) })}
                />
              </div>
              <div className="prop-row">
                <label className="prop-label">Estilo</label>
                <div className="btn-group">
                  <button
                    className={`style-btn ${selectedObjectProps.fontWeight === 'bold' ? 'active' : ''}`}
                    onClick={() => updateProp({ fontWeight: selectedObjectProps.fontWeight === 'bold' ? 'normal' : 'bold' })}
                  >
                    <b>N</b>
                  </button>
                  <button
                    className={`style-btn ${selectedObjectProps.fontStyle === 'italic' ? 'active' : ''}`}
                    onClick={() => updateProp({ fontStyle: selectedObjectProps.fontStyle === 'italic' ? 'normal' : 'italic' })}
                  >
                    <i>I</i>
                  </button>
                </div>
              </div>
              <div className="prop-row">
                <label className="prop-label">Alineación</label>
                <div className="btn-group">
                  {(['left', 'center', 'right'] as const).map((align) => (
                    <button
                      key={align}
                      className={`style-btn ${selectedObjectProps.textAlign === align ? 'active' : ''}`}
                      onClick={() => updateProp({ textAlign: align })}
                    >
                      {align === 'left' ? '≡ Izq' : align === 'center' ? '≡ Cen' : '≡ Der'}
                    </button>
                  ))}
                </div>
              </div>
              <ColorInput label="Color texto" value={selectedObjectProps.fill ?? '#000000'} onChange={updateFill} />
            </div>
          )}

          {!isText && (
            <div className="prop-section">
              <div className="prop-section-title">Figura</div>
              <ColorInput label="Relleno" value={selectedObjectProps.fill ?? 'transparent'} onChange={updateFill} />
              <ColorInput label="Borde" value={selectedObjectProps.stroke ?? '#000000'} onChange={updateStroke} />
              <div className="prop-row">
                <label className="prop-label">Grosor</label>
                <input
                  type="range"
                  min={0}
                  max={20}
                  value={selectedObjectProps.strokeWidth ?? 2}
                  onChange={(e) => updateProp({ strokeWidth: Number(e.target.value) })}
                  className="prop-range"
                />
                <span className="prop-value">{selectedObjectProps.strokeWidth ?? 2}px</span>
              </div>
            </div>
          )}

          <div className="prop-section">
            <div className="prop-section-title">Apariencia</div>
            <div className="prop-row">
              <label className="prop-label">Opacidad</label>
              <input
                type="range"
                min={10}
                max={100}
                value={Math.round((selectedObjectProps.opacity ?? 1) * 100)}
                onChange={(e) => updateOpacity(Number(e.target.value))}
                className="prop-range"
              />
              <span className="prop-value">{Math.round((selectedObjectProps.opacity ?? 1) * 100)}%</span>
            </div>
          </div>
        </>
      ) : (
        <div className="no-selection">
          Seleccioná un elemento para ver sus propiedades
        </div>
      )}
    </div>
  );
}
