import { fabric } from 'fabric';
import { Download, Stamp } from 'lucide-react';
import { useStampStore } from '../store/useStampStore';
import { STAMP_SIZES } from '../types';
import { exportToPng, getExportDimensions } from '../utils/export';

interface HeaderProps {
  canvasRef: React.MutableRefObject<fabric.Canvas | null>;
}

export function Header({ canvasRef }: HeaderProps) {
  const { stampSize, setStampSize, stampShape, setStampShape } = useStampStore();

  const dims = getExportDimensions(stampSize);

  const handleExport = () => {
    const fc = canvasRef.current;
    if (!fc) return;
    exportToPng(fc, stampSize, stampShape);
  };

  return (
    <header className="app-header">
      <div className="header-brand">
        <Stamp size={24} />
        <span>CreaSellos</span>
      </div>

      <div className="header-controls">
        <div className="size-control">
          <label>Tamaño:</label>
          <select
            value={STAMP_SIZES.findIndex((s) => s.label === stampSize.label)}
            onChange={(e) => {
              const sz = STAMP_SIZES[Number(e.target.value)];
              setStampSize(sz);
              setStampShape(sz.shape);
            }}
            className="size-select"
          >
            {STAMP_SIZES.map((sz, i) => (
              <option key={sz.label} value={i}>{sz.label}</option>
            ))}
          </select>
        </div>

        <div className="export-info">
          <span className="dim-badge">
            PNG: {dims.widthPx}×{dims.heightPx}px · {dims.dpi} DPI
          </span>
        </div>

        <button className="export-btn" onClick={handleExport}>
          <Download size={18} />
          Exportar PNG
        </button>
      </div>
    </header>
  );
}
