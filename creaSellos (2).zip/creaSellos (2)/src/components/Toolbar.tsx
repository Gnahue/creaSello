import { fabric } from 'fabric';
import { MousePointer2, Type, Shapes, Trash2, Copy, RotateCcw, MoveUp, MoveDown } from 'lucide-react';
import { useStampStore } from '../store/useStampStore';

interface ToolbarProps {
  canvasRef: React.MutableRefObject<fabric.Canvas | null>;
}

export function Toolbar({ canvasRef }: ToolbarProps) {
  const { activeTool, setActiveTool } = useStampStore();

  const addText = () => {
    const fc = canvasRef.current;
    if (!fc) return;
    const text = new fabric.IText('Texto', {
      left: fc.getWidth() / 2,
      top: fc.getHeight() / 2,
      originX: 'center',
      originY: 'center',
      fontSize: 24,
      fontFamily: 'Arial',
      fill: '#000000',
      fontWeight: 'normal',
    });
    fc.add(text);
    fc.setActiveObject(text);
    fc.renderAll();
    text.enterEditing();
    text.selectAll();
    setActiveTool('select');
  };

  const deleteSelected = () => {
    const fc = canvasRef.current;
    if (!fc) return;
    const active = fc.getActiveObjects();
    active.forEach((obj) => fc.remove(obj));
    fc.discardActiveObject();
    fc.renderAll();
  };

  const duplicateSelected = () => {
    const fc = canvasRef.current;
    if (!fc) return;
    const active = fc.getActiveObject();
    if (!active) return;
    active.clone((cloned: fabric.Object) => {
      cloned.set({ left: (cloned.left ?? 0) + 15, top: (cloned.top ?? 0) + 15 });
      fc.add(cloned);
      fc.setActiveObject(cloned);
      fc.renderAll();
    });
  };

  const bringForward = () => {
    const fc = canvasRef.current;
    if (!fc) return;
    const active = fc.getActiveObject();
    if (active) {
      fc.bringForward(active);
      fc.renderAll();
    }
  };

  const sendBackward = () => {
    const fc = canvasRef.current;
    if (!fc) return;
    const active = fc.getActiveObject();
    if (active) {
      fc.sendBackwards(active);
      fc.renderAll();
    }
  };

  const clearCanvas = () => {
    const fc = canvasRef.current;
    if (!fc) return;
    if (window.confirm('¿Borrar todo el diseño?')) {
      fc.clear();
      fc.setBackgroundColor('#ffffff', () => fc.renderAll());
    }
  };

  return (
    <div className="toolbar">
      <div className="toolbar-group">
        <button
          className={`tool-btn ${activeTool === 'select' ? 'active' : ''}`}
          onClick={() => setActiveTool('select')}
          title="Seleccionar (V)"
        >
          <MousePointer2 size={20} />
        </button>
        <button
          className={`tool-btn ${activeTool === 'text' ? 'active' : ''}`}
          onClick={addText}
          title="Agregar texto (T)"
        >
          <Type size={20} />
        </button>
        <button
          className={`tool-btn ${activeTool === 'shape' ? 'active' : ''}`}
          onClick={() => setActiveTool('shape')}
          title="Figuras"
        >
          <Shapes size={20} />
        </button>
      </div>

      <div className="toolbar-divider" />

      <div className="toolbar-group">
        <button className="tool-btn" onClick={duplicateSelected} title="Duplicar">
          <Copy size={18} />
        </button>
        <button className="tool-btn" onClick={bringForward} title="Traer adelante">
          <MoveUp size={18} />
        </button>
        <button className="tool-btn" onClick={sendBackward} title="Enviar atrás">
          <MoveDown size={18} />
        </button>
      </div>

      <div className="toolbar-divider" />

      <div className="toolbar-group">
        <button className="tool-btn danger" onClick={deleteSelected} title="Eliminar selección (Del)">
          <Trash2 size={18} />
        </button>
        <button className="tool-btn danger" onClick={clearCanvas} title="Limpiar todo">
          <RotateCcw size={18} />
        </button>
      </div>
    </div>
  );
}
