import { useState } from 'react';
import { fabric } from 'fabric';
import { SHAPES } from '../utils/shapes';
import { type ShapeAsset } from '../types';

interface ShapePanelProps {
  canvasRef: React.MutableRefObject<fabric.Canvas | null>;
}

type Category = 'all' | 'basic' | 'decorative' | 'symbols';

const CATEGORY_LABELS: Record<Category, string> = {
  all: 'Todos',
  basic: 'Básicas',
  decorative: 'Decorativas',
  symbols: 'Símbolos',
};

export function ShapePanel({ canvasRef }: ShapePanelProps) {
  const [activeCategory, setActiveCategory] = useState<Category>('all');

  const filteredShapes = activeCategory === 'all'
    ? SHAPES
    : SHAPES.filter((s) => s.category === activeCategory);

  const addShape = (shape: ShapeAsset) => {
    const fc = canvasRef.current;
    if (!fc) return;

    fabric.loadSVGFromURL(shape.path, (objects, options) => {
      const group = fabric.util.groupSVGElements(objects, options);
      const maxSize = Math.min(fc.getWidth(), fc.getHeight()) * 0.6;
      const scale = maxSize / Math.max(group.width ?? 100, group.height ?? 100);
      group.set({
        left: fc.getWidth() / 2,
        top: fc.getHeight() / 2,
        originX: 'center',
        originY: 'center',
        scaleX: scale,
        scaleY: scale,
        stroke: '#000000',
        strokeWidth: 2 / scale,
      });

      // Make all child objects inherit color
      const grp = group as fabric.Group;
      if (grp._objects) {
        grp._objects.forEach((obj: fabric.Object) => {
          if ((obj as fabric.Path).fill === 'currentColor' || (obj as fabric.Path).fill === '') {
            obj.set({ fill: 'transparent' });
          }
        });
      }

      fc.add(group);
      fc.setActiveObject(group);
      fc.renderAll();
    });
  };

  return (
    <div className="shape-panel">
      <div className="panel-header">Figuras</div>
      <div className="shape-categories">
        {(Object.keys(CATEGORY_LABELS) as Category[]).map((cat) => (
          <button
            key={cat}
            className={`cat-btn ${activeCategory === cat ? 'active' : ''}`}
            onClick={() => setActiveCategory(cat)}
          >
            {CATEGORY_LABELS[cat]}
          </button>
        ))}
      </div>
      <div className="shape-grid">
        {filteredShapes.map((shape) => (
          <button
            key={shape.id}
            className="shape-item"
            onClick={() => addShape(shape)}
            title={shape.name}
          >
            <img src={shape.preview} alt={shape.name} className="shape-preview" />
            <span className="shape-name">{shape.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
