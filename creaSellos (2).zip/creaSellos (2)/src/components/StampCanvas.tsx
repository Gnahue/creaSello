import { useEffect, useRef, useCallback } from 'react';
import { fabric } from 'fabric';
import { useStampStore } from '../store/useStampStore';
import { DISPLAY_PX_PER_MM } from '../types';

interface StampCanvasProps {
  canvasRef: React.MutableRefObject<fabric.Canvas | null>;
}

export function StampCanvas({ canvasRef }: StampCanvasProps) {
  const elRef = useRef<HTMLCanvasElement>(null);
  const { stampSize, stampShape, stampBackground, setActiveTool, setSelectedObjectProps } = useStampStore();

  const canvasWidth = stampSize.widthMm * DISPLAY_PX_PER_MM;
  const canvasHeight = stampSize.heightMm * DISPLAY_PX_PER_MM;

  const handleSelection = useCallback((obj: fabric.Object | null) => {
    if (!obj) {
      setSelectedObjectProps(null);
      return;
    }
    const props: Record<string, unknown> = {
      opacity: obj.opacity,
      strokeWidth: obj.strokeWidth,
      stroke: obj.stroke,
      scaleX: obj.scaleX,
      scaleY: obj.scaleY,
    };
    if (obj.type === 'i-text' || obj.type === 'text') {
      const t = obj as fabric.IText;
      props.fontSize = t.fontSize;
      props.fontFamily = t.fontFamily;
      props.fill = t.fill as string;
      props.fontWeight = t.fontWeight as string;
      props.fontStyle = t.fontStyle as string;
      props.textAlign = t.textAlign;
    } else {
      props.fill = obj.fill as string;
    }
    setSelectedObjectProps(props);
  }, [setSelectedObjectProps]);

  useEffect(() => {
    if (!elRef.current) return;

    const fc = new fabric.Canvas(elRef.current, {
      width: canvasWidth,
      height: canvasHeight,
      backgroundColor: stampBackground,
      selection: true,
      preserveObjectStacking: true,
    });

    canvasRef.current = fc;

    fc.on('selection:created', (e) => handleSelection(e.selected?.[0] ?? null));
    fc.on('selection:updated', (e) => handleSelection(e.selected?.[0] ?? null));
    fc.on('selection:cleared', () => handleSelection(null));
    fc.on('object:modified', (e) => handleSelection(e.target ?? null));
    fc.on('mouse:dblclick', () => setActiveTool('text'));

    return () => {
      fc.dispose();
      canvasRef.current = null;
    };
  }, []);

  // Resize canvas when stamp size changes
  useEffect(() => {
    const fc = canvasRef.current;
    if (!fc) return;
    fc.setWidth(canvasWidth);
    fc.setHeight(canvasHeight);
    fc.renderAll();
  }, [canvasWidth, canvasHeight]);

  // Update background color
  useEffect(() => {
    const fc = canvasRef.current;
    if (!fc) return;
    fc.setBackgroundColor(stampBackground, () => fc.renderAll());
  }, [stampBackground]);

  const clipPath = stampShape === 'circle'
    ? `ellipse(${canvasWidth / 2}px ${canvasHeight / 2}px at ${canvasWidth / 2}px ${canvasHeight / 2}px)`
    : undefined;

  return (
    <div className="stamp-canvas-wrapper">
      <div
        className="stamp-canvas-clip"
        style={{
          width: canvasWidth,
          height: canvasHeight,
          clipPath,
          overflow: 'hidden',
          borderRadius: stampShape === 'circle' ? '50%' : '0',
        }}
      >
        <canvas ref={elRef} />
      </div>
      <div className="stamp-dimensions">
        {stampSize.widthMm} × {stampSize.heightMm} mm
        &nbsp;·&nbsp;
        {stampShape === 'circle' ? 'Redondo' : 'Rectangular'}
      </div>
    </div>
  );
}
